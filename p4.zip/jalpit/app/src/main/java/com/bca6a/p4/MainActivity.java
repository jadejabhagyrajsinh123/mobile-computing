package com.bca6a.p4;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioButton r1,r2,r3;
    RadioGroup rg;
    ImageView img ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            rg = findViewById(R.id.rg);
            r1 = findViewById(R.id.india);
            r2 = findViewById(R.id.japan);
            r3 = findViewById(R.id.fiji);
            img = findViewById(R.id.img);

            rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if (r1.isChecked()){
                        img.setImageResource(R.drawable.india);
                    } else if (r2.isChecked()) {
                        img.setImageResource(R.drawable.japan);
                    } else if (r3.isChecked()) {
                        img.setImageResource(R.drawable.fiji);
                    }
                }
            });




            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}