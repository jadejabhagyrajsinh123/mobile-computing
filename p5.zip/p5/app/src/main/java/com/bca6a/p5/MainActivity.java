package com.bca6a.p5;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView txt;
    CheckBox ch;
    ToggleButton tb;
    Switch sw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            ch = findViewById(R.id.chbox);
            txt = findViewById(R.id.txt);
            tb = findViewById(R.id.tb);
            sw = findViewById(R.id.sw);

            ch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(ch.isChecked()){
                        txt.setTextSize(50);
                    }
                    else {
                        txt.setTextSize(20);
                    }
                }
            });

           tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
               @Override
               public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
                   if(tb.isChecked()){
                       txt.setTextSize(50);
                   }
                   else {
                       txt.setTextSize(20);
                   }
               }
           });


           sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

               @Override
               public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
                   if (sw.isChecked()){
                       txt.setTextSize(50);
                       txt.setTextColor(Color.parseColor("#E91E63"));

                   }
                   else {
                       txt.setTextSize(20);
                       txt.setTextColor(Color.parseColor("#000000"));
                   }
               }
           });
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}